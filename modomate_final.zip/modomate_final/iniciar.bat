@echo off
chcp 65001 >nul
echo.
echo ============================================
echo   Modo Mate — Iniciando sistema...
echo ============================================
echo.
echo Abriendo el navegador en http://localhost:5000
echo Para cerrar el sistema, cerrá esta ventana.
echo.
start "" http://localhost:5000
python app.py
pause

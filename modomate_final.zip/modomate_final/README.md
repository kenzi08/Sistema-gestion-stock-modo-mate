# Modo Mate — Sistema de Gestión

Sistema de gestión de stock, ventas, caja y reportes para negocios de mates.

---

## Instalación (Windows)

### Paso 1 — Instalar Python
1. Ir a https://www.python.org/downloads/
2. Descargar la última versión de Python 3
3. **MUY IMPORTANTE**: Durante la instalación, tildar la casilla **"Add Python to PATH"**
4. Completar la instalación

### Paso 2 — Instalar el sistema
1. Descomprimí la carpeta `modomate` en algún lugar fácil, por ejemplo `C:\ModoMate\`
2. Hacé doble clic en **`instalar.bat`**
3. Esperá a que termine (instala las dependencias automáticamente)

### Paso 3 — Iniciar el sistema
- Doble clic en **`iniciar.bat`**
- Se abre el navegador automáticamente en `http://localhost:5000`
- ¡Listo!

---

## Usuarios iniciales

| Nombre | Usuario | Contraseña | Rol |
|--------|---------|------------|-----|
| Admin | `admin` | `admin123` | Encargado |
| Juan C. | `juan` | `empleado123` | Empleado |

**Importante**: Cambiá las contraseñas desde la sección Empleados cuando ingreses por primera vez.

---

## Permisos por rol

| Función | Encargado | Empleado |
|---------|-----------|----------|
| Ver Home / Dashboard | ✅ (con ganancia neta) | ✅ (sin ganancia neta) |
| Crear / ver ventas | ✅ | ✅ |
| Editar ventas | ✅ | ✅ |
| Anular ventas | ✅ | ✅ |
| Ver / crear productos | ✅ | ✅ |
| Ver stock y movimientos | ✅ | ✅ |
| Caja (abrir/ver) | ✅ | ✅ |
| Caja (cerrar) | ✅ | ❌ |
| Compras | ✅ | ❌ |
| Gastos | ✅ | ✅ |
| Empleados y usuarios | ✅ | ❌ |
| Reportes con facturación | ✅ | ❌ |

---

## Usar en más de una computadora (red local)

Si tienen varias computadoras en el mismo local (conectadas a la misma red WiFi o cable), pueden usar el sistema desde cualquiera de ellas. Solo una PC actúa como **servidor**.

### En la PC servidor:
1. Instalar y ejecutar el sistema normalmente con `iniciar.bat`
2. Averiguar la IP local de esa PC:
   - Abrí el menú Inicio → escribí `cmd` → Enter
   - Escribí `ipconfig` → Enter
   - Buscá **"Dirección IPv4"**, por ejemplo: `192.168.1.100`

### En las otras PCs (clientes):
1. No necesitan instalar nada
2. Abrir el navegador (Chrome, Firefox, Edge)
3. Escribir en la barra de dirección: `http://192.168.1.100:5000` (reemplazando con la IP del servidor)
4. ¡Listo! Todos ven los mismos datos en tiempo real

> **Nota**: La PC servidor tiene que estar prendida para que las otras puedan conectarse. Si apagás el servidor, el sistema no estará disponible desde las otras computadoras.

---

## Base de datos

- Todos los datos se guardan en el archivo `modomate.db` dentro de la carpeta del sistema
- Es un archivo SQLite — no necesita servidor de base de datos
- **Nunca borres ese archivo** — ahí están todas las ventas, productos y clientes
- Para hacer un backup, simplemente copiá el archivo `modomate.db` a otro lugar

---

## Funcionalidades incluidas

- **Login con roles**: encargado y empleado con permisos diferenciados
- **Dashboard**: métricas del mes, últimas ventas, alertas de stock
- **Ventas**: crear, editar, ver historial con filtros, datos de envío
- **Número de orden automático** en cada venta
- **Nombre del cliente** por venta
- **Datos de envío** (nombre, dirección, teléfono) opcionales
- **Productos**: ABM completo con precio de costo, margen, IVA y precio de venta calculado
- **Combos**: agrupan productos y descuentan stock individual al vender
- **Stock**: historial completo de movimientos (entradas, salidas, ajustes)
- **Alertas de stock bajo** en el dashboard
- **Caja**: apertura, movimientos del día, cierre (solo encargado)
- **Compras**: registro de órdenes a proveedores con actualización automática de stock
- **Gastos**: registro de egresos con categorías
- **Empleados**: gestión de usuarios, roles y comisiones por empleado
- **Reportes**: ingresos, ganancia neta, gastos, top productos, ventas por mes, comisiones (solo encargado)

---

## Soporte

Si algo no funciona, verificá que:
1. Python esté correctamente instalado (`python --version` en cmd)
2. Las dependencias estén instaladas (ejecutar `instalar.bat` de nuevo)
3. El puerto 5000 no esté siendo usado por otro programa

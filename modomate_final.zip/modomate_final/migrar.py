import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'modomate.db')

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# Agregar columna descuento_monto si no existe
try:
    cursor.execute("ALTER TABLE ventas ADD COLUMN descuento_monto REAL DEFAULT 0")
    conn.commit()
    print("[OK] Columna 'descuento_monto' agregada a la tabla ventas.")
except Exception as e:
    if 'duplicate column' in str(e).lower():
        print("[OK] La columna ya existia, no se necesita migrar.")
    else:
        print(f"[ERROR] {e}")

conn.close()
print("Migracion completada.")

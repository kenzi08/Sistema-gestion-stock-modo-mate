from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, make_response
from functools import wraps
import sqlite3
import bcrypt
import os
from datetime import datetime
from contextlib import contextmanager

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'modomate-secret-key-2026-cambiar-en-produccion')
DB_PATH = os.path.join(os.path.dirname(__file__), 'modomate.db')

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            usuario TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            rol TEXT NOT NULL CHECK(rol IN ('encargado','empleado')),
            comision_pct REAL DEFAULT 0,
            activo INTEGER DEFAULT 1,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS categorias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT UNIQUE NOT NULL
        );
        CREATE TABLE IF NOT EXISTS proveedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            contacto TEXT,
            telefono TEXT,
            email TEXT,
            direccion TEXT,
            notas TEXT,
            activo INTEGER DEFAULT 1,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT UNIQUE NOT NULL,
            codigo_barra TEXT,
            nombre TEXT NOT NULL,
            categoria_id INTEGER REFERENCES categorias(id),
            proveedor_id INTEGER REFERENCES proveedores(id),
            unidad TEXT DEFAULT 'Unidad',
            stock INTEGER DEFAULT 0,
            stock_minimo INTEGER DEFAULT 0,
            precio_costo REAL DEFAULT 0,
            margen_pct REAL DEFAULT 0,
            iva_pct REAL DEFAULT 21,
            precio_venta REAL DEFAULT 0,
            descripcion TEXT,
            es_combo INTEGER DEFAULT 0,
            activo INTEGER DEFAULT 1,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS combo_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            combo_id INTEGER NOT NULL REFERENCES productos(id),
            producto_id INTEGER NOT NULL REFERENCES productos(id),
            cantidad INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS ventas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nro_orden INTEGER UNIQUE NOT NULL,
            tipo_comprobante TEXT DEFAULT 'Detalle de venta',
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER REFERENCES usuarios(id),
            nombre_cliente TEXT DEFAULT 'Consumidor final',
            envio_nombre TEXT,
            envio_direccion TEXT,
            envio_telefono TEXT,
            metodo_pago TEXT DEFAULT 'Efectivo',
            cuenta_pago TEXT,
            subtotal REAL DEFAULT 0,
            descuento_general_pct REAL DEFAULT 0,
            descuento_monto REAL DEFAULT 0,
            total REAL DEFAULT 0,
            observacion TEXT,
            estado TEXT DEFAULT 'completada' CHECK(estado IN ('completada','pendiente_envio','anulada')),
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS venta_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venta_id INTEGER NOT NULL REFERENCES ventas(id),
            producto_id INTEGER NOT NULL REFERENCES productos(id),
            cantidad INTEGER NOT NULL,
            precio_unitario REAL NOT NULL,
            descuento_pct REAL DEFAULT 0,
            subtotal REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS movimientos_stock (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            producto_id INTEGER NOT NULL REFERENCES productos(id),
            tipo TEXT NOT NULL CHECK(tipo IN ('entrada','salida','ajuste')),
            cantidad INTEGER NOT NULL,
            stock_resultante INTEGER NOT NULL,
            referencia TEXT,
            venta_id INTEGER REFERENCES ventas(id),
            usuario_id INTEGER REFERENCES usuarios(id),
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS compras (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            proveedor_id INTEGER REFERENCES proveedores(id),
            total REAL DEFAULT 0,
            estado TEXT DEFAULT 'recibida',
            observacion TEXT
        );
        CREATE TABLE IF NOT EXISTS compra_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            compra_id INTEGER NOT NULL REFERENCES compras(id),
            producto_id INTEGER NOT NULL REFERENCES productos(id),
            cantidad INTEGER NOT NULL,
            precio_unitario REAL NOT NULL,
            subtotal REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS gastos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            categoria TEXT NOT NULL,
            descripcion TEXT,
            importe REAL NOT NULL,
            usuario_id INTEGER REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS caja_sesiones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo_caja TEXT DEFAULT 'chica' CHECK(tipo_caja IN ('chica','grande')),
            abierta_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            cerrada_en TIMESTAMP,
            saldo_inicial REAL DEFAULT 0,
            saldo_final REAL,
            usuario_id INTEGER REFERENCES usuarios(id),
            estado TEXT DEFAULT 'abierta' CHECK(estado IN ('abierta','cerrada'))
        );
        CREATE TABLE IF NOT EXISTS caja_movimientos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sesion_id INTEGER NOT NULL REFERENCES caja_sesiones(id),
            tipo TEXT NOT NULL CHECK(tipo IN ('ingreso','egreso','apertura','cierre')),
            descripcion TEXT,
            importe REAL NOT NULL,
            referencia_venta INTEGER REFERENCES ventas(id),
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        _seed_initial_data(db)

def _seed_initial_data(db):
    existing = db.execute("SELECT COUNT(*) as c FROM usuarios").fetchone()['c']
    if existing > 0:
        return
    hash_enc = bcrypt.hashpw('admin123'.encode(), bcrypt.gensalt()).decode()
    hash_emp = bcrypt.hashpw('empleado123'.encode(), bcrypt.gensalt()).decode()
    db.execute("INSERT INTO usuarios (nombre,usuario,password_hash,rol,comision_pct) VALUES (?,?,?,?,?)",
               ('Admin','admin',hash_enc,'encargado',5.0))
    db.execute("INSERT INTO usuarios (nombre,usuario,password_hash,rol,comision_pct) VALUES (?,?,?,?,?)",
               ('Juan C.','juan',hash_emp,'empleado',3.0))
    for cat in ['Mates','Bombillas','Termos','Combos','Accesorios']:
        db.execute("INSERT OR IGNORE INTO categorias (nombre) VALUES (?)",(cat,))
    db.execute("INSERT INTO proveedores (nombre,contacto,telefono) VALUES (?,?,?)",
               ('Distribuidora Yerba S.A.','Carlos','011-4444-5555'))
    db.execute("INSERT INTO productos (codigo,nombre,categoria_id,stock,stock_minimo,precio_costo,precio_venta,margen_pct) VALUES (?,?,?,?,?,?,?,?)",
               ('MAT-001','Mate calabaza grande',1,32,10,4200,8500,50))
    db.execute("INSERT INTO productos (codigo,nombre,categoria_id,stock,stock_minimo,precio_costo,precio_venta,margen_pct) VALUES (?,?,?,?,?,?,?,?)",
               ('MAT-002','Mate calabaza chico',1,0,10,3100,6000,50))
    db.execute("INSERT INTO productos (codigo,nombre,categoria_id,stock,stock_minimo,precio_costo,precio_venta,margen_pct) VALUES (?,?,?,?,?,?,?,?)",
               ('BOM-001','Bombilla alpaca 18cm',2,4,20,2100,4200,50))
    db.execute("INSERT INTO productos (codigo,nombre,categoria_id,stock,stock_minimo,precio_costo,precio_venta,margen_pct) VALUES (?,?,?,?,?,?,?,?)",
               ('BOM-002','Bombilla acero 20cm',2,55,20,1900,3800,50))
    db.execute("INSERT INTO productos (codigo,nombre,categoria_id,stock,stock_minimo,precio_costo,precio_venta,margen_pct) VALUES (?,?,?,?,?,?,?,?)",
               ('TER-001','Termo 1L acero',3,6,15,9000,18000,50))

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'usuario_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def encargado_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'usuario_id' not in session:
            return redirect(url_for('login'))
        if session.get('rol') != 'encargado':
            flash('No tenés permiso para acceder a esta sección.', 'error')
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated

def get_next_orden():
    with get_db() as db:
        r = db.execute("SELECT MAX(nro_orden) as m FROM ventas").fetchone()
        return (r['m'] or 0) + 1

def _descontar_stock(db, items_data, nro, venta_id):
    for item in items_data:
        prod = db.execute("SELECT * FROM productos WHERE id=?", (item['producto_id'],)).fetchone()
        if not prod:
            continue
        if prod['es_combo']:
            for ci in db.execute("SELECT * FROM combo_items WHERE combo_id=?", (prod['id'],)).fetchall():
                cant = ci['cantidad'] * item['cantidad']
                db.execute("UPDATE productos SET stock=stock-? WHERE id=?", (cant, ci['producto_id']))
                ns = db.execute("SELECT stock FROM productos WHERE id=?", (ci['producto_id'],)).fetchone()['stock']
                db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,venta_id,usuario_id) VALUES (?,?,?,?,?,?,?)",
                           (ci['producto_id'],'salida',cant,ns,f'Venta #{nro} (combo)',venta_id,session['usuario_id']))
        else:
            db.execute("UPDATE productos SET stock=stock-? WHERE id=?", (item['cantidad'], item['producto_id']))
            ns = db.execute("SELECT stock FROM productos WHERE id=?", (item['producto_id'],)).fetchone()['stock']
            db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,venta_id,usuario_id) VALUES (?,?,?,?,?,?,?)",
                       (item['producto_id'],'salida',item['cantidad'],ns,f'Venta #{nro}',venta_id,session['usuario_id']))

def _restaurar_stock(db, venta_id, nro):
    for item in db.execute("SELECT * FROM venta_items WHERE venta_id=?", (venta_id,)).fetchall():
        prod = db.execute("SELECT * FROM productos WHERE id=?", (item['producto_id'],)).fetchone()
        if not prod:
            continue
        if prod['es_combo']:
            for ci in db.execute("SELECT * FROM combo_items WHERE combo_id=?", (prod['id'],)).fetchall():
                cant = ci['cantidad'] * item['cantidad']
                db.execute("UPDATE productos SET stock=stock+? WHERE id=?", (cant, ci['producto_id']))
                ns = db.execute("SELECT stock FROM productos WHERE id=?", (ci['producto_id'],)).fetchone()['stock']
                db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,venta_id,usuario_id) VALUES (?,?,?,?,?,?,?)",
                           (ci['producto_id'],'entrada',cant,ns,f'Revert #{nro}',venta_id,session['usuario_id']))
        else:
            db.execute("UPDATE productos SET stock=stock+? WHERE id=?", (item['cantidad'], item['producto_id']))
            ns = db.execute("SELECT stock FROM productos WHERE id=?", (item['producto_id'],)).fetchone()['stock']
            db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,venta_id,usuario_id) VALUES (?,?,?,?,?,?,?)",
                       (item['producto_id'],'entrada',item['cantidad'],ns,f'Revert #{nro}',venta_id,session['usuario_id']))

# ─── Login ────────────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        usuario = request.form.get('usuario','').strip()
        password = request.form.get('password','').strip()
        with get_db() as db:
            u = db.execute("SELECT * FROM usuarios WHERE usuario=? AND activo=1",(usuario,)).fetchone()
        if u and bcrypt.checkpw(password.encode(), u['password_hash'].encode()):
            session['usuario_id'] = u['id']
            session['nombre'] = u['nombre']
            session['rol'] = u['rol']
            session['usuario'] = u['usuario']
            return redirect(url_for('home'))
        flash('Usuario o contraseña incorrectos.', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ─── Home ─────────────────────────────────────────────────────────────────────

@app.route('/')
@login_required
def home():
    with get_db() as db:
        mes = datetime.now().strftime('%Y-%m')
        ingresos = db.execute("SELECT COALESCE(SUM(total),0) as t FROM ventas WHERE strftime('%Y-%m',fecha)=? AND estado!='anulada'",(mes,)).fetchone()['t']
        nro_ventas = db.execute("SELECT COUNT(*) as c FROM ventas WHERE strftime('%Y-%m',fecha)=? AND estado!='anulada'",(mes,)).fetchone()['c']
        costos_reales = db.execute("SELECT COALESCE(SUM(vi.cantidad*p.precio_costo),0) as c FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id JOIN productos p ON p.id=vi.producto_id WHERE strftime('%Y-%m',v.fecha)=? AND v.estado!='anulada'",(mes,)).fetchone()['c']
        gastos_mes = db.execute("SELECT COALESCE(SUM(importe),0) as t FROM gastos WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['t']
        comisiones_mes = db.execute("""SELECT COALESCE(SUM(v.total * u.comision_pct / 100),0) as c
            FROM ventas v JOIN usuarios u ON u.id=v.usuario_id
            WHERE strftime('%Y-%m',v.fecha)=? AND v.estado!='anulada' AND u.rol='empleado'""", (mes,)).fetchone()['c']
        ganancia = ingresos - costos_reales - gastos_mes - comisiones_mes
        ticket_prom = (ingresos/nro_ventas) if nro_ventas>0 else 0
        stock_bajo = db.execute("SELECT COUNT(*) as c FROM productos WHERE stock<=stock_minimo AND activo=1").fetchone()['c']
        ultimas_ventas = db.execute("SELECT v.*,u.nombre as empleado_nombre FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id ORDER BY v.fecha DESC LIMIT 8").fetchall()
        alertas = db.execute("SELECT * FROM productos WHERE stock<=stock_minimo AND activo=1 ORDER BY stock ASC LIMIT 6").fetchall()
    return render_template('home.html', ingresos=ingresos, ganancia=ganancia,
        nro_ventas=nro_ventas, ticket_prom=ticket_prom, stock_bajo=stock_bajo,
        ultimas_ventas=ultimas_ventas, alertas=alertas)

# ─── Ventas ───────────────────────────────────────────────────────────────────

@app.route('/ventas')
@login_required
def ventas():
    fecha_desde = request.args.get('desde','')
    fecha_hasta = request.args.get('hasta','')
    buscar = request.args.get('buscar','')
    estado = request.args.get('estado','')
    with get_db() as db:
        q = "SELECT v.*,u.nombre as empleado_nombre FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE 1=1"
        params = []
        if fecha_desde: q += " AND DATE(v.fecha)>=?"; params.append(fecha_desde)
        if fecha_hasta: q += " AND DATE(v.fecha)<=?"; params.append(fecha_hasta)
        if buscar: q += " AND (v.nombre_cliente LIKE ? OR CAST(v.nro_orden AS TEXT) LIKE ?)"; params+=[f'%{buscar}%',f'%{buscar}%']
        if estado: q += " AND v.estado=?"; params.append(estado)
        q += " ORDER BY v.fecha DESC"
        ventas_list = db.execute(q, params).fetchall()
    return render_template('ventas.html', ventas=ventas_list,
        fecha_desde=fecha_desde, fecha_hasta=fecha_hasta, buscar=buscar, estado=estado)

@app.route('/ventas/nueva', methods=['GET','POST'])
@login_required
def nueva_venta():
    if request.method == 'POST':
        data = request.get_json()
        if not data or not data.get('items'):
            return jsonify({'error': 'Sin productos'}), 400
        nro = get_next_orden()
        with get_db() as db:
            subtotal = sum(i['subtotal'] for i in data['items'])
            desc_g = float(data.get('descuento_general_pct', 0))
            desc_monto = float(data.get('descuento_monto', 0))
            # desc_monto ya viene calculado desde el frontend (monto real a descontar)
            # desc_g es el porcentaje guardado como referencia, pero el total usa desc_monto
            total = subtotal - desc_monto
            cur = db.execute("""INSERT INTO ventas
                (nro_orden,tipo_comprobante,usuario_id,nombre_cliente,
                 envio_nombre,envio_direccion,envio_telefono,
                 metodo_pago,cuenta_pago,subtotal,descuento_general_pct,descuento_monto,total,observacion,estado)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                nro, data.get('tipo_comprobante','Detalle de venta'),
                data.get('usuario_id') or session['usuario_id'],
                data.get('nombre_cliente','Consumidor final'),
                data.get('envio_nombre',''), data.get('envio_direccion',''), data.get('envio_telefono',''),
                data.get('metodo_pago','Efectivo'), data.get('cuenta_pago','Caja chica'),
                subtotal, desc_g, desc_monto, total, data.get('observacion',''), data.get('estado','completada')
            ))
            venta_id = cur.lastrowid
            for item in data['items']:
                db.execute("INSERT INTO venta_items (venta_id,producto_id,cantidad,precio_unitario,descuento_pct,subtotal) VALUES (?,?,?,?,?,?)",
                           (venta_id,item['producto_id'],item['cantidad'],item['precio_unitario'],item.get('descuento_pct',0),item['subtotal']))
            _descontar_stock(db, data['items'], nro, venta_id)
        return jsonify({'ok': True, 'nro_orden': nro, 'venta_id': venta_id})

    with get_db() as db:
        productos = db.execute("SELECT * FROM productos WHERE activo=1 ORDER BY nombre").fetchall()
        empleados = db.execute("SELECT id,nombre,rol FROM usuarios WHERE activo=1 ORDER BY nombre").fetchall()
        nro_siguiente = get_next_orden()
    return render_template('nueva_venta.html', productos=productos, empleados=empleados, nro_siguiente=nro_siguiente)

@app.route('/ventas/<int:vid>/editar', methods=['GET','POST'])
@login_required
def editar_venta(vid):
    with get_db() as db:
        venta = db.execute("SELECT * FROM ventas WHERE id=?", (vid,)).fetchone()
        if not venta:
            flash('Orden no encontrada.', 'error')
            return redirect(url_for('ventas'))

        if request.method == 'POST':
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Sin datos'}), 400
            _restaurar_stock(db, vid, venta['nro_orden'])
            db.execute("DELETE FROM venta_items WHERE venta_id=?", (vid,))
            items = data.get('items', [])
            subtotal = sum(i['subtotal'] for i in items)
            desc_g = float(data.get('descuento_general_pct', 0))
            desc_monto_e2 = float(data.get('descuento_monto', 0))
            total = subtotal - desc_monto_e2
            db.execute("""UPDATE ventas SET nombre_cliente=?,estado=?,envio_nombre=?,
                envio_direccion=?,envio_telefono=?,observacion=?,
                metodo_pago=?,cuenta_pago=?,subtotal=?,descuento_general_pct=?,descuento_monto=?,total=?,
                tipo_comprobante=?,usuario_id=?
                WHERE id=?""", (
                data.get('nombre_cliente','Consumidor final'),
                data.get('estado', venta['estado']),
                data.get('envio_nombre',''), data.get('envio_direccion',''), data.get('envio_telefono',''),
                data.get('observacion',''), data.get('metodo_pago', venta['metodo_pago']),
                data.get('cuenta_pago', venta['cuenta_pago']),
                subtotal, desc_g, desc_monto_e2, total,
                data.get('tipo_comprobante', venta['tipo_comprobante']),
                data.get('usuario_id', venta['usuario_id']),
                vid
            ))
            for item in items:
                db.execute("INSERT INTO venta_items (venta_id,producto_id,cantidad,precio_unitario,descuento_pct,subtotal) VALUES (?,?,?,?,?,?)",
                           (vid,item['producto_id'],item['cantidad'],item['precio_unitario'],item.get('descuento_pct',0),item['subtotal']))
            _descontar_stock(db, items, venta['nro_orden'], vid)
            return jsonify({'ok': True})

        items = db.execute("SELECT vi.*,p.nombre as prod_nombre,p.codigo FROM venta_items vi JOIN productos p ON p.id=vi.producto_id WHERE vi.venta_id=?",(vid,)).fetchall()
        productos = db.execute("SELECT * FROM productos WHERE activo=1 ORDER BY nombre").fetchall()
        empleados = db.execute("SELECT id,nombre,rol FROM usuarios WHERE activo=1 ORDER BY nombre").fetchall()
    return render_template('editar_venta.html', venta=venta, items=items, productos=productos, empleados=empleados)

@app.route('/ventas/<int:vid>/detalle')
@login_required
def detalle_venta(vid):
    with get_db() as db:
        venta = db.execute("SELECT v.*,u.nombre as empleado_nombre,u.comision_pct,u.rol as empleado_rol FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE v.id=?",(vid,)).fetchone()
        if not venta:
            flash('Orden no encontrada.', 'error')
            return redirect(url_for('ventas'))
        items = db.execute("SELECT vi.*,p.nombre as prod_nombre,p.codigo FROM venta_items vi JOIN productos p ON p.id=vi.producto_id WHERE vi.venta_id=?",(vid,)).fetchall()
    comision_monto = venta['total'] * (venta['comision_pct'] or 0) / 100
    return render_template('detalle_venta.html', venta=venta, items=items, comision_monto=comision_monto)

@app.route('/ventas/<int:vid>/pdf')
@login_required
def pdf_venta(vid):
    with get_db() as db:
        venta = db.execute("SELECT v.*,u.nombre as empleado_nombre FROM ventas v LEFT JOIN usuarios u ON u.id=v.usuario_id WHERE v.id=?",(vid,)).fetchone()
        if not venta:
            return "Orden no encontrada", 404
        items = db.execute("SELECT vi.*,p.nombre as prod_nombre,p.codigo FROM venta_items vi JOIN productos p ON p.id=vi.producto_id WHERE vi.venta_id=?",(vid,)).fetchall()
    html = render_template('pdf_venta.html', venta=venta, items=items)
    response = make_response(html)
    response.headers['Content-Type'] = 'text/html; charset=utf-8'
    return response

# ─── API ──────────────────────────────────────────────────────────────────────

@app.route('/api/productos/buscar')
@login_required
def api_buscar_productos():
    q = request.args.get('q','')
    with get_db() as db:
        prods = db.execute("""SELECT p.id,p.codigo,p.nombre,p.precio_venta,p.stock,p.es_combo
            FROM productos p WHERE p.activo=1
            AND (p.nombre LIKE ? OR p.codigo LIKE ? OR p.codigo_barra LIKE ?)
            ORDER BY p.nombre LIMIT 10""", (f'%{q}%',f'%{q}%',f'%{q}%')).fetchall()
    return jsonify([dict(p) for p in prods])

# ─── Productos ────────────────────────────────────────────────────────────────

@app.route('/productos')
@login_required
def productos():
    buscar = request.args.get('buscar','')
    categoria = request.args.get('categoria','')
    estado = request.args.get('estado','')
    with get_db() as db:
        q = "SELECT p.*,c.nombre as cat_nombre FROM productos p LEFT JOIN categorias c ON c.id=p.categoria_id WHERE p.activo=1"
        params = []
        if buscar: q += " AND (p.nombre LIKE ? OR p.codigo LIKE ?)"; params+=[f'%{buscar}%',f'%{buscar}%']
        if categoria: q += " AND p.categoria_id=?"; params.append(categoria)
        if estado == 'sin_stock': q += " AND p.stock=0"
        elif estado == 'stock_bajo': q += " AND p.stock>0 AND p.stock<=p.stock_minimo"
        elif estado == 'en_stock': q += " AND p.stock>p.stock_minimo"
        q += " ORDER BY p.nombre"
        prods = db.execute(q, params).fetchall()
        cats = db.execute("SELECT * FROM categorias ORDER BY nombre").fetchall()
    return render_template('productos.html', productos=prods, categorias=cats,
                           buscar=buscar, categoria_sel=categoria, estado_sel=estado)

@app.route('/productos/nuevo', methods=['GET','POST'])
@login_required
def nuevo_producto():
    if request.method == 'POST':
        codigo = request.form.get('codigo','').strip()
        nombre = request.form.get('nombre','').strip()
        if not codigo or not nombre:
            flash('Código y nombre son obligatorios.', 'error')
        else:
            es_combo = 1 if request.form.get('es_combo') else 0
            try:
                with get_db() as db:
                    # Si es combo: stock=0, costo=suma de items
                    precio_costo_final = float(request.form.get('precio_costo','0') or 0)
                    stock_final = int(request.form.get('stock','0') or 0)
                    if es_combo:
                        combo_prods_ids = request.form.getlist('combo_producto_id')
                        combo_cants = request.form.getlist('combo_cantidad')
                        costo_sum = 0
                        for cpid, ccant in zip(combo_prods_ids, combo_cants):
                            if cpid and ccant:
                                p_row = db.execute("SELECT precio_costo FROM productos WHERE id=?", (int(cpid),)).fetchone()
                                if p_row:
                                    costo_sum += p_row['precio_costo'] * int(ccant)
                        precio_costo_final = costo_sum
                        stock_final = 0
                    cur = db.execute("""INSERT INTO productos
                        (codigo,codigo_barra,nombre,categoria_id,proveedor_id,unidad,
                         stock,stock_minimo,precio_costo,margen_pct,iva_pct,precio_venta,descripcion,es_combo)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                        codigo, request.form.get('codigo_barra',''),
                        nombre,
                        request.form.get('categoria_id') or None,
                        request.form.get('proveedor_id') or None,
                        request.form.get('unidad','Unidad'),
                        stock_final,
                        0,
                        precio_costo_final,
                        float(request.form.get('margen_pct','0') or 0),
                        float(request.form.get('iva_pct','21') or 21),
                        float(request.form.get('precio_venta','0') or 0),
                        request.form.get('descripcion',''), es_combo
                    ))
                    prod_id = cur.lastrowid
                    if es_combo:
                        for cpid, ccant in zip(request.form.getlist('combo_producto_id'), request.form.getlist('combo_cantidad')):
                            if cpid and ccant:
                                db.execute("INSERT INTO combo_items (combo_id,producto_id,cantidad) VALUES (?,?,?)",
                                           (prod_id,int(cpid),int(ccant)))
                    if not es_combo and stock_final > 0:
                        db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,usuario_id) VALUES (?,?,?,?,?,?)",
                                   (prod_id,'entrada',stock_final,stock_final,'Stock inicial',session['usuario_id']))
                flash(f'Producto "{nombre}" creado correctamente.', 'success')
                return redirect(url_for('productos'))
            except Exception as e:
                flash(f'Error al crear el producto. Verificá que el código no exista ya. ({e})', 'error')

    with get_db() as db:
        cats = db.execute("SELECT * FROM categorias ORDER BY nombre").fetchall()
        provs = db.execute("SELECT * FROM proveedores WHERE activo=1 ORDER BY nombre").fetchall()
        todos_prod = [dict(r) for r in db.execute("SELECT id,nombre,codigo,precio_costo FROM productos WHERE activo=1 AND es_combo=0 ORDER BY nombre").fetchall()]
    return render_template('nuevo_producto.html', categorias=cats, proveedores=provs, todos_prod=todos_prod)

@app.route('/productos/<int:pid>/editar', methods=['GET','POST'])
@login_required
def editar_producto(pid):
    with get_db() as db:
        prod = db.execute("SELECT * FROM productos WHERE id=?", (pid,)).fetchone()
        cats = db.execute("SELECT * FROM categorias ORDER BY nombre").fetchall()
        provs = db.execute("SELECT * FROM proveedores WHERE activo=1").fetchall()
        todos_prod = [dict(r) for r in db.execute("SELECT id,nombre,codigo,precio_costo FROM productos WHERE activo=1 AND es_combo=0 AND id!=? ORDER BY nombre", (pid,)).fetchall()]
        combo_items_actuales = [dict(r) for r in db.execute("""SELECT ci.producto_id, ci.cantidad, p.nombre, p.codigo, p.precio_costo
            FROM combo_items ci JOIN productos p ON p.id=ci.producto_id
            WHERE ci.combo_id=?""", (pid,)).fetchall()]
        if request.method == 'POST':
            db.execute("""UPDATE productos SET nombre=?,categoria_id=?,proveedor_id=?,
                unidad=?,stock_minimo=?,precio_costo=?,margen_pct=?,iva_pct=?,precio_venta=?,descripcion=?
                WHERE id=?""", (
                request.form.get('nombre'),
                request.form.get('categoria_id') or None,
                request.form.get('proveedor_id') or None,
                request.form.get('unidad','Unidad'),
                int(request.form.get('stock_minimo','0') or 0),
                float(request.form.get('precio_costo','0') or 0),
                float(request.form.get('margen_pct','0') or 0),
                float(request.form.get('iva_pct','21') or 21),
                float(request.form.get('precio_venta','0') or 0),
                request.form.get('descripcion',''), pid
            ))
            # Si es combo, actualizar items y recalcular costo
            if prod['es_combo']:
                db.execute("DELETE FROM combo_items WHERE combo_id=?", (pid,))
                costo_sum = 0
                for cpid, ccant in zip(request.form.getlist('combo_producto_id'), request.form.getlist('combo_cantidad')):
                    if cpid and ccant:
                        db.execute("INSERT INTO combo_items (combo_id,producto_id,cantidad) VALUES (?,?,?)",
                                   (pid, int(cpid), int(ccant)))
                        p_row = db.execute("SELECT precio_costo FROM productos WHERE id=?", (int(cpid),)).fetchone()
                        if p_row:
                            costo_sum += p_row['precio_costo'] * int(ccant)
                db.execute("UPDATE productos SET precio_costo=?, stock=0 WHERE id=?", (costo_sum, pid))
            ajuste = request.form.get('ajuste_stock','').strip()
            if ajuste:
                nuevo_stock = int(ajuste)
                db.execute("UPDATE productos SET stock=? WHERE id=?", (nuevo_stock, pid))
                db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,usuario_id) VALUES (?,?,?,?,?,?)",
                           (pid,'ajuste',nuevo_stock-prod['stock'],nuevo_stock,'Ajuste manual',session['usuario_id']))
            flash('Producto actualizado.', 'success')
            return redirect(url_for('productos'))
    return render_template('editar_producto.html', producto=prod, categorias=cats, proveedores=provs,
                           todos_prod=todos_prod, combo_items_actuales=combo_items_actuales)


@app.route('/productos/<int:pid>/eliminar', methods=['POST'])
@encargado_required
def eliminar_producto(pid):
    with get_db() as db:
        prod = db.execute("SELECT nombre FROM productos WHERE id=?", (pid,)).fetchone()
        if not prod:
            flash('Producto no encontrado.', 'error')
            return redirect(url_for('productos'))
        # Soft delete: marcar como inactivo
        db.execute("UPDATE productos SET activo=0 WHERE id=?", (pid,))
        flash(f'Producto "{prod["nombre"]}" eliminado.', 'success')
    return redirect(url_for('productos'))

# ─── Proveedores ──────────────────────────────────────────────────────────────

@app.route('/proveedores')
@encargado_required
def proveedores():
    with get_db() as db:
        lista = db.execute("SELECT * FROM proveedores ORDER BY nombre").fetchall()
    return render_template('proveedores.html', proveedores=lista)

@app.route('/proveedores/nuevo', methods=['GET','POST'])
@encargado_required
def nuevo_proveedor():
    if request.method == 'POST':
        nombre = request.form.get('nombre','').strip()
        if not nombre:
            flash('El nombre es obligatorio.', 'error')
            return render_template('nuevo_proveedor.html')
        with get_db() as db:
            db.execute("INSERT INTO proveedores (nombre,contacto,telefono,email,direccion,notas) VALUES (?,?,?,?,?,?)",
                       (nombre, request.form.get('contacto',''), request.form.get('telefono',''),
                        request.form.get('email',''), request.form.get('direccion',''), request.form.get('notas','')))
        flash(f'Proveedor "{nombre}" creado.', 'success')
        return redirect(url_for('proveedores'))
    return render_template('nuevo_proveedor.html')

@app.route('/proveedores/<int:pid>/editar', methods=['GET','POST'])
@encargado_required
def editar_proveedor(pid):
    with get_db() as db:
        prov = db.execute("SELECT * FROM proveedores WHERE id=?", (pid,)).fetchone()
        if request.method == 'POST':
            db.execute("""UPDATE proveedores SET nombre=?,contacto=?,telefono=?,email=?,direccion=?,notas=?,activo=?
                WHERE id=?""", (
                request.form.get('nombre'), request.form.get('contacto',''),
                request.form.get('telefono',''), request.form.get('email',''),
                request.form.get('direccion',''), request.form.get('notas',''),
                1 if request.form.get('activo') else 0, pid
            ))
            flash('Proveedor actualizado.', 'success')
            return redirect(url_for('proveedores'))
    return render_template('editar_proveedor.html', proveedor=prov)

# ─── Caja ─────────────────────────────────────────────────────────────────────

@app.route('/caja')
@login_required
def caja():
    with get_db() as db:
        sesiones = db.execute("SELECT * FROM caja_sesiones WHERE estado='abierta' ORDER BY id DESC").fetchall()
        historial = db.execute("SELECT * FROM caja_sesiones WHERE estado='cerrada' ORDER BY abierta_en DESC LIMIT 10").fetchall()
        movimientos_por_sesion = {}
        for s in sesiones:
            movimientos_por_sesion[s['id']] = db.execute(
                "SELECT * FROM caja_movimientos WHERE sesion_id=? ORDER BY fecha DESC", (s['id'],)).fetchall()
    return render_template('caja.html', sesiones=sesiones, historial=historial,
                           movimientos_por_sesion=movimientos_por_sesion)

@app.route('/caja/abrir', methods=['POST'])
@login_required
def abrir_caja():
    saldo_inicial = float(request.form.get('saldo_inicial','0') or 0)
    tipo_caja = request.form.get('tipo_caja','chica')
    with get_db() as db:
        ya = db.execute("SELECT id FROM caja_sesiones WHERE estado='abierta' AND tipo_caja=?", (tipo_caja,)).fetchone()
        if ya:
            flash(f'La caja {"chica" if tipo_caja=="chica" else "grande"} ya está abierta.', 'error')
            return redirect(url_for('caja'))
        cur = db.execute("INSERT INTO caja_sesiones (tipo_caja,saldo_inicial,usuario_id) VALUES (?,?,?)",
                         (tipo_caja, saldo_inicial, session['usuario_id']))
        sid = cur.lastrowid
        db.execute("INSERT INTO caja_movimientos (sesion_id,tipo,descripcion,importe) VALUES (?,?,?,?)",
                   (sid,'apertura',f'Apertura caja {"chica" if tipo_caja=="chica" else "grande"}',saldo_inicial))
    flash('Caja abierta correctamente.', 'success')
    return redirect(url_for('caja'))

@app.route('/caja/cerrar', methods=['POST'])
@encargado_required
def cerrar_caja():
    sid = int(request.form.get('sesion_id',0))
    with get_db() as db:
        s = db.execute("SELECT * FROM caja_sesiones WHERE id=? AND estado='abierta'", (sid,)).fetchone()
        if not s:
            flash('Sesión no encontrada.', 'error')
            return redirect(url_for('caja'))
        ingresos = db.execute("SELECT COALESCE(SUM(importe),0) as t FROM caja_movimientos WHERE sesion_id=? AND tipo IN ('ingreso','apertura')", (sid,)).fetchone()['t']
        egresos = db.execute("SELECT COALESCE(SUM(importe),0) as t FROM caja_movimientos WHERE sesion_id=? AND tipo='egreso'", (sid,)).fetchone()['t']
        saldo_final = ingresos - egresos
        db.execute("UPDATE caja_sesiones SET estado='cerrada',cerrada_en=CURRENT_TIMESTAMP,saldo_final=? WHERE id=?", (saldo_final, sid))
        db.execute("INSERT INTO caja_movimientos (sesion_id,tipo,descripcion,importe) VALUES (?,?,?,?)",
                   (sid,'cierre','Cierre de caja',saldo_final))
    flash('Caja cerrada.', 'success')
    return redirect(url_for('caja'))

# ─── Compras ──────────────────────────────────────────────────────────────────

@app.route('/compras')
@login_required
def compras():
    with get_db() as db:
        mes = datetime.now().strftime('%Y-%m')
        comp_mes = db.execute("SELECT COALESCE(SUM(total),0) as t FROM compras WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['t']
        n_mes = db.execute("SELECT COUNT(*) as c FROM compras WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['c']
        lista = db.execute("SELECT c.*,p.nombre as prov_nombre FROM compras c LEFT JOIN proveedores p ON p.id=c.proveedor_id ORDER BY c.fecha DESC").fetchall()
    return render_template('compras.html', compras=lista, comp_mes=comp_mes, n_mes=n_mes)

@app.route('/compras/nueva', methods=['GET','POST'])
@encargado_required
def nueva_compra():
    with get_db() as db:
        provs = db.execute("SELECT * FROM proveedores WHERE activo=1 ORDER BY nombre").fetchall()
        prods = [{"id": r["id"], "nombre": r["nombre"], "codigo": r["codigo"], "stock": r["stock"], "precio_costo": float(r["precio_costo"] or 0)} for r in db.execute("SELECT id,nombre,codigo,stock,precio_costo FROM productos WHERE activo=1 ORDER BY nombre").fetchall()]
        if request.method == 'POST':
            data = request.get_json()
            if not data:
                return jsonify({'error': 'Sin datos'}), 400
            modo = data.get('modo', 'productos')
            total = float(data.get('total', 0))
            cur = db.execute("INSERT INTO compras (proveedor_id,total,estado,observacion) VALUES (?,?,?,?)",
                             (data.get('proveedor_id') or None, total, 'recibida', data.get('observacion','')))
            cid = cur.lastrowid
            if modo == 'productos':
                for item in data.get('items', []):
                    db.execute("INSERT INTO compra_items (compra_id,producto_id,cantidad,precio_unitario,subtotal) VALUES (?,?,?,?,?)",
                               (cid,item['producto_id'],item['cantidad'],item['precio_unitario'],item['subtotal']))
                    db.execute("UPDATE productos SET stock=stock+? WHERE id=?", (item['cantidad'],item['producto_id']))
                    ns = db.execute("SELECT stock FROM productos WHERE id=?", (item['producto_id'],)).fetchone()['stock']
                    db.execute("INSERT INTO movimientos_stock (producto_id,tipo,cantidad,stock_resultante,referencia,usuario_id) VALUES (?,?,?,?,?,?)",
                               (item['producto_id'],'entrada',item['cantidad'],ns,f'Compra #{cid}',session['usuario_id']))
            return jsonify({'ok': True})
    return render_template('nueva_compra.html', proveedores=provs, productos=prods)

# ─── Gastos ───────────────────────────────────────────────────────────────────

@app.route('/gastos')
@login_required
def gastos():
    with get_db() as db:
        mes = datetime.now().strftime('%Y-%m')
        eg_hoy = db.execute("SELECT COALESCE(SUM(importe),0) as t FROM gastos WHERE DATE(fecha)=DATE('now')").fetchone()['t']
        eg_mes = db.execute("SELECT COALESCE(SUM(importe),0) as t FROM gastos WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['t']
        n_hoy = db.execute("SELECT COUNT(*) as c FROM gastos WHERE DATE(fecha)=DATE('now')").fetchone()['c']
        n_mes = db.execute("SELECT COUNT(*) as c FROM gastos WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['c']
        lista = db.execute("SELECT g.*,u.nombre as uname FROM gastos g LEFT JOIN usuarios u ON u.id=g.usuario_id ORDER BY g.fecha DESC").fetchall()
    return render_template('gastos.html', gastos=lista, eg_hoy=eg_hoy, eg_mes=eg_mes, n_hoy=n_hoy, n_mes=n_mes)

@app.route('/gastos/<int:gid>/eliminar', methods=['POST'])
@encargado_required
def eliminar_gasto(gid):
    with get_db() as db:
        db.execute("DELETE FROM gastos WHERE id=?", (gid,))
    flash('Gasto eliminado.', 'success')
    return redirect(url_for('gastos'))

@app.route('/gastos/nuevo', methods=['POST'])
@login_required
def nuevo_gasto():
    with get_db() as db:
        db.execute("INSERT INTO gastos (categoria,descripcion,importe,usuario_id) VALUES (?,?,?,?)",
                   (request.form.get('categoria',''), request.form.get('descripcion',''),
                    float(request.form.get('importe','0') or 0), session['usuario_id']))
    flash('Gasto registrado.', 'success')
    return redirect(url_for('gastos'))

# ─── Empleados ────────────────────────────────────────────────────────────────

@app.route('/empleados')
@encargado_required
def empleados():
    with get_db() as db:
        mes = datetime.now().strftime('%Y-%m')
        lista = db.execute("SELECT * FROM usuarios ORDER BY rol,nombre").fetchall()
        comisiones = {}
        for u in lista:
            vm = db.execute("SELECT COALESCE(SUM(total),0) as t FROM ventas WHERE usuario_id=? AND strftime('%Y-%m',fecha)=? AND estado!='anulada'", (u['id'],mes)).fetchone()['t']
            comisiones[u['id']] = {'ventas': vm, 'comision': vm * u['comision_pct'] / 100}
    return render_template('empleados.html', empleados=lista, comisiones=comisiones)

@app.route('/empleados/nuevo', methods=['POST'])
@encargado_required
def nuevo_empleado():
    nombre = request.form.get('nombre','').strip()
    usuario_name = request.form.get('usuario','').strip()
    password = request.form.get('password','').strip()
    rol = request.form.get('rol','empleado')
    comision = float(request.form.get('comision_pct','0') or 0)
    if not nombre or not usuario_name or not password:
        flash('Todos los campos son obligatorios.', 'error')
        return redirect(url_for('empleados'))
    hash_p = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    with get_db() as db:
        try:
            db.execute("INSERT INTO usuarios (nombre,usuario,password_hash,rol,comision_pct) VALUES (?,?,?,?,?)",
                       (nombre,usuario_name,hash_p,rol,comision))
            flash(f'Usuario "{nombre}" creado.', 'success')
        except Exception:
            flash('El nombre de usuario ya existe.', 'error')
    return redirect(url_for('empleados'))

@app.route('/empleados/<int:uid>/toggle', methods=['POST'])
@encargado_required
def toggle_empleado(uid):
    with get_db() as db:
        db.execute("UPDATE usuarios SET activo=1-activo WHERE id=?", (uid,))
    return redirect(url_for('empleados'))

@app.route('/empleados/<int:uid>/comision', methods=['POST'])
@encargado_required
def editar_comision(uid):
    comision = float(request.form.get('comision_pct', 0) or 0)
    with get_db() as db:
        db.execute("UPDATE usuarios SET comision_pct=? WHERE id=?", (comision, uid))
    flash('Comisión actualizada.', 'success')
    return redirect(url_for('empleados'))

# ─── Reportes ─────────────────────────────────────────────────────────────────

@app.route('/reportes')
@encargado_required
def reportes():
    with get_db() as db:
        mes = datetime.now().strftime('%Y-%m')
        ingresos = db.execute("SELECT COALESCE(SUM(total),0) as t FROM ventas WHERE strftime('%Y-%m',fecha)=? AND estado!='anulada'", (mes,)).fetchone()['t']
        nro_ventas = db.execute("SELECT COUNT(*) as c FROM ventas WHERE strftime('%Y-%m',fecha)=? AND estado!='anulada'", (mes,)).fetchone()['c']
        costos = db.execute("SELECT COALESCE(SUM(vi.cantidad*p.precio_costo),0) as c FROM venta_items vi JOIN ventas v ON v.id=vi.venta_id JOIN productos p ON p.id=vi.producto_id WHERE strftime('%Y-%m',v.fecha)=? AND v.estado!='anulada'", (mes,)).fetchone()['c']
        gastos_mes = db.execute("SELECT COALESCE(SUM(importe),0) as t FROM gastos WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['t']
        compras_mes = db.execute("SELECT COALESCE(SUM(total),0) as t FROM compras WHERE strftime('%Y-%m',fecha)=?", (mes,)).fetchone()['t']
        comisiones_mes = db.execute("""SELECT COALESCE(SUM(v.total * u.comision_pct / 100),0) as c
            FROM ventas v JOIN usuarios u ON u.id=v.usuario_id
            WHERE strftime('%Y-%m',v.fecha)=? AND v.estado!='anulada' AND u.rol='empleado'""", (mes,)).fetchone()['c']
        ganancia = ingresos - costos - gastos_mes - comisiones_mes
        ticket_prom = (ingresos/nro_ventas) if nro_ventas>0 else 0
        top_prods = db.execute("""SELECT p.nombre,SUM(vi.cantidad) as total_cant,SUM(vi.subtotal) as total_venta
            FROM venta_items vi JOIN productos p ON p.id=vi.producto_id JOIN ventas v ON v.id=vi.venta_id
            WHERE strftime('%Y-%m',v.fecha)=? AND v.estado!='anulada'
            GROUP BY vi.producto_id ORDER BY total_cant DESC LIMIT 8""", (mes,)).fetchall()
        ventas_x_mes = db.execute("SELECT strftime('%Y-%m',fecha) as mes,COALESCE(SUM(total),0) as total,COUNT(*) as cant FROM ventas WHERE estado!='anulada' GROUP BY mes ORDER BY mes DESC LIMIT 6").fetchall()
        comisiones = db.execute("""SELECT u.nombre,u.rol,u.comision_pct,COALESCE(SUM(v.total),0) as ventas_total
            FROM usuarios u LEFT JOIN ventas v ON v.usuario_id=u.id
            AND strftime('%Y-%m',v.fecha)=? AND v.estado!='anulada'
            WHERE u.activo=1 GROUP BY u.id ORDER BY ventas_total DESC""", (mes,)).fetchall()
    return render_template('reportes.html', ingresos=ingresos, ganancia=ganancia, nro_ventas=nro_ventas,
        gastos_mes=gastos_mes, compras_mes=compras_mes, ticket_prom=ticket_prom,
        top_prods=top_prods, ventas_x_mes=ventas_x_mes, comisiones=comisiones)

@app.route('/ventas/<int:vid>/anular', methods=['POST'])
@encargado_required
def anular_venta(vid):
    with get_db() as db:
        venta = db.execute("SELECT * FROM ventas WHERE id=?", (vid,)).fetchone()
        if not venta:
            flash('Venta no encontrada.', 'error')
            return redirect(url_for('ventas'))
        if venta['estado'] == 'anulada':
            flash('La venta ya estaba anulada.', 'error')
            return redirect(url_for('ventas'))
        _restaurar_stock(db, vid, venta['nro_orden'])
        db.execute("UPDATE ventas SET estado='anulada' WHERE id=?", (vid,))
    flash(f'Venta #{ venta["nro_orden"]:04d} anulada. El stock fue restaurado.', 'success')
    return redirect(url_for('ventas'))

# ─── Stock ────────────────────────────────────────────────────────────────────

@app.route('/stock')
@login_required
def stock():
    with get_db() as db:
        movs = db.execute("""SELECT m.*,p.nombre as prod_nombre,p.codigo,u.nombre as uname
            FROM movimientos_stock m JOIN productos p ON p.id=m.producto_id
            LEFT JOIN usuarios u ON u.id=m.usuario_id ORDER BY m.fecha DESC LIMIT 100""").fetchall()
    return render_template('stock.html', movimientos=movs)

# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    init_db()
    print("\n" + "="*50)
    print("  Modo Mate — Sistema de Gestión")
    print("="*50)
    print("  Abrí tu navegador en: http://localhost:5000")
    print()
    print("  Usuarios iniciales:")
    print("    Encargado → usuario: admin    / clave: admin123")
    print("    Empleado  → usuario: juan     / clave: empleado123")
    print("="*50 + "\n")
    app.run(debug=False, host='0.0.0.0', port=5000)

"""
MODO MATE — Inicialización versión final
Ejecutar UNA SOLA VEZ antes de arrancar el sistema por primera vez.
Crea la base de datos con solo el usuario administrador.
"""
import sqlite3
import os
import sys

try:
    import bcrypt
except ImportError:
    print("[ERROR] Falta instalar bcrypt. Ejecutá: pip install bcrypt")
    sys.exit(1)

DB_PATH = os.path.join(os.path.dirname(__file__), 'modomate.db')

if os.path.exists(DB_PATH):
    resp = input(f"\nYa existe una base de datos en {DB_PATH}\n¿Querés reemplazarla? (s/n): ").strip().lower()
    if resp != 's':
        print("Cancelado.")
        sys.exit(0)
    os.remove(DB_PATH)

conn = sqlite3.connect(DB_PATH)
conn.row_factory = sqlite3.Row
conn.execute("PRAGMA foreign_keys = ON")

print("\nCreando base de datos limpia...")

conn.executescript("""
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    usuario TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    rol TEXT NOT NULL CHECK(rol IN ('encargado','empleado')),
    comision_pct REAL DEFAULT 0,
    activo INTEGER DEFAULT 1,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT UNIQUE NOT NULL
);
CREATE TABLE IF NOT EXISTS proveedores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    contacto TEXT,
    telefono TEXT,
    email TEXT,
    direccion TEXT,
    notas TEXT,
    activo INTEGER DEFAULT 1,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT UNIQUE NOT NULL,
    codigo_barra TEXT,
    nombre TEXT NOT NULL,
    categoria_id INTEGER REFERENCES categorias(id),
    proveedor_id INTEGER REFERENCES proveedores(id),
    unidad TEXT DEFAULT 'Unidad',
    stock INTEGER DEFAULT 0,
    stock_minimo INTEGER DEFAULT 0,
    precio_costo REAL DEFAULT 0,
    margen_pct REAL DEFAULT 0,
    iva_pct REAL DEFAULT 21,
    precio_venta REAL DEFAULT 0,
    descripcion TEXT,
    es_combo INTEGER DEFAULT 0,
    activo INTEGER DEFAULT 1,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS combo_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    combo_id INTEGER NOT NULL REFERENCES productos(id),
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    cantidad INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nro_orden INTEGER UNIQUE NOT NULL,
    tipo_comprobante TEXT DEFAULT 'Detalle de venta',
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario_id INTEGER REFERENCES usuarios(id),
    nombre_cliente TEXT DEFAULT 'Consumidor final',
    envio_nombre TEXT,
    envio_direccion TEXT,
    envio_telefono TEXT,
    metodo_pago TEXT DEFAULT 'Efectivo',
    cuenta_pago TEXT,
    subtotal REAL DEFAULT 0,
    descuento_general_pct REAL DEFAULT 0,
    descuento_monto REAL DEFAULT 0,
    total REAL DEFAULT 0,
    observacion TEXT,
    estado TEXT DEFAULT 'completada',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS venta_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id INTEGER NOT NULL REFERENCES ventas(id),
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    cantidad INTEGER NOT NULL,
    precio_unitario REAL NOT NULL,
    descuento_pct REAL DEFAULT 0,
    subtotal REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS movimientos_stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    tipo TEXT NOT NULL,
    cantidad INTEGER NOT NULL,
    stock_resultante INTEGER NOT NULL,
    referencia TEXT,
    venta_id INTEGER REFERENCES ventas(id),
    usuario_id INTEGER REFERENCES usuarios(id),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS compras (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    proveedor_id INTEGER REFERENCES proveedores(id),
    total REAL DEFAULT 0,
    estado TEXT DEFAULT 'recibida',
    observacion TEXT
);
CREATE TABLE IF NOT EXISTS compra_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    compra_id INTEGER NOT NULL REFERENCES compras(id),
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    cantidad INTEGER NOT NULL,
    precio_unitario REAL NOT NULL,
    subtotal REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS gastos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    categoria TEXT NOT NULL,
    descripcion TEXT,
    importe REAL NOT NULL,
    usuario_id INTEGER REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS caja_sesiones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo_caja TEXT DEFAULT 'chica',
    abierta_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cerrada_en TIMESTAMP,
    saldo_inicial REAL DEFAULT 0,
    saldo_final REAL,
    usuario_id INTEGER REFERENCES usuarios(id),
    estado TEXT DEFAULT 'abierta'
);
CREATE TABLE IF NOT EXISTS caja_movimientos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sesion_id INTEGER NOT NULL REFERENCES caja_sesiones(id),
    tipo TEXT NOT NULL,
    descripcion TEXT,
    importe REAL NOT NULL,
    referencia_venta INTEGER REFERENCES ventas(id),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")

# Solo admin
hash_admin = bcrypt.hashpw('admin123'.encode(), bcrypt.gensalt()).decode()
conn.execute("INSERT INTO usuarios (nombre,usuario,password_hash,rol,comision_pct) VALUES (?,?,?,?,?)",
             ('Admin','admin', hash_admin, 'encargado', 0))

# Categorías vacías para que el cliente las use
for cat in ['Mates','Bombillas','Termos','Combos','Accesorios','Yerbas']:
    conn.execute("INSERT OR IGNORE INTO categorias (nombre) VALUES (?)", (cat,))

conn.commit()
conn.close()

print("\n" + "="*50)
print("  Base de datos creada exitosamente!")
print("="*50)
print()
print("  Usuario administrador:")
print("    Usuario:    admin")
print("    Contraseña: admin123")
print()
print("  IMPORTANTE: Cambiá la contraseña del admin")
print("  desde la sección Empleados al ingresar.")
print("="*50)
print("\nAhora podés ejecutar iniciar.bat")

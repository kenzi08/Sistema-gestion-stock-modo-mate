@echo off
chcp 65001 >nul
echo.
echo ============================================
echo   Modo Mate - Instalador (Version Final)
echo ============================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no esta instalado.
    echo Descargalo desde: https://www.python.org/downloads/
    pause
    exit /b 1
)
echo [OK] Python encontrado.
echo.
echo Instalando dependencias...
pip install flask bcrypt --quiet
echo [OK] Dependencias instaladas.
echo.
echo Inicializando base de datos limpia...
python init_final.py
echo.
echo ============================================
echo   Instalacion completada!
echo   Ejecuta iniciar.bat para arrancar.
echo ============================================
echo.
pause
